const express = require('express');
const router = express.Router();
const { loginAdmin } = require('../contollers/adminController.js');
const { registerAdmin } = require('../contollers/dynamodbController.js');
const path = require('path');

router.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, '../views', 'register.html'));
});

router.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'adminLogin.html'));
});

router.post('/register1', registerAdmin);

router.post('/login', loginAdmin);


module.exports = router;