const express = require("express");
const cors = require('cors');
const router = require("./routes/route.js");



const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(express.urlencoded({ extended: true })); // To handle form data
app.use(express.static("public"));

app.use(cors({
    origin: 'http://localhost:3000',
    methods: ['POST', 'GET', 'OPTIONS', 'PUT', 'DELETE'],
    headers: ['Content-Type', 'Accept', 'Origin', 'X-Requested-With']
  }));



  
  
  app.use("/", router);
  
  app.get('/', (req, res) => {
    res.send('SERVER IS RUNNING');
  });
  
  app.get('*', (req, res) => {
    res.send('PAGE NOT FOUND');
  });
  
  app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
  });