module.exports = {
  EMAIL: "anubhavj280@gmail.com",
  PASSWORD: "epavktrxdjqksgmh",

  //for ses email
  HOST: "email-smtp.ap-south-1.amazonaws.com",
  USER: "AKIASE5KQ4M4S6PO3B6U",
  AWSPASS: "BBLnaujyctAkNg588qKV1qGkXSxa1cyGRJzCJNNYSyOY",

  
  SECRET_KEY: "Strata333",

  // for s3
  //DEV BUCKET
  AWS_ACCESS_KEY_ID: "AKIASE5KQ4M47ABEBYMD",
  AWS_SECRET_ACCESS_KEY: "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",
  AWS_REGION: "ap-south-1",
  AWS_BUCKET_NAME: "windowparking",

  //Test Bucket
  // AWS_ACCESS_KEY_ID: "AKIAQE3RORWHSZKOOTIJ",
  // AWS_SECRET_ACCESS_KEY: "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",
  // AWS_REGION: "ap-south-1",
  // AWS_BUCKET_NAME: "buckettest000001",

  //for iam user : teamUser
  AWS_ACCOUNT_ID: "954976327254",

    //for jwt
  JWT_SECRET: "secert_key_for_jwt"

};
