const bcrypt = require('bcrypt');

// Function to hash a password
async function hashPassword(password) {
    const saltRounds = 10; // Number of salt rounds for bcrypt
    try {
        const hashedPassword = await bcrypt.hash(password, saltRounds);
        return hashedPassword;
    } catch (err) {
        console.error('Error hashing password', err);
        throw new Error('Hashing failed');
    }
}

// Function to verify a password
async function verifyPassword(password, hashedPassword) {
    try {
        const match = await bcrypt.compare(password, hashedPassword);
        return match;
    } catch (err) {
        console.error('Error verifying password', err);
        throw new Error('Verification failed');
    }
}

module.exports = {
    hashPassword,
    verifyPassword
};