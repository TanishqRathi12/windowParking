const { createTable, saveDataToDynamo,checkOrganizationExists ,getItemData} = require('./dynamodbController');
const { createFolder } = require('./s3Controller');
const { hashPassword ,verifyPassword} = require('../utils/hashUtils');



const loginAdmin = async (req, res) => {
    const { adminName, parkingName, password } = req.body;
    const tableName = 'Parking_Organization';

    try {
        // Retrieve admin data from DynamoDB
        const adminData = await getItemData(tableName, `ORG#${parkingName}`, `ADMIN#${adminName}`);
        
        if (!adminData) {
            return res.status(404).json({ error: 'Admin not found' });
        }

        // Verify the password
        const passwordMatch = await verifyPassword(password, adminData.HashedPassword);
        if (!passwordMatch) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        // Successful login
        res.status(200).json({ message: 'Login successful' });
    } catch (err) {
        res.status(500).json({ error: 'Error logging in' });
    }
}



module.exports = {
    loginAdmin
};