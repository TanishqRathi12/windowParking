const bcrypt = require('bcrypt');
const { documentClient, dynamoDB } = require('../awsClients/dynamoClient');
const { CreateTableCommand, waitForTableExists, DescribeTableCommand, ScanCommand } = require('@aws-sdk/client-dynamodb');
const { PutCommand, GetCommand,DeleteCommand, UpdateCommand,QueryCommand } = require('@aws-sdk/lib-dynamodb');
const { generateHash } = require('../utils/hashUtils');

 
const tableName = 'Parking_Organization';
 
const createTable = async (tableName, partitionKey, sortKey) => {
    const schema = schemas[tableName] || schemas.default;
    const params = {
        TableName: tableName,
        KeySchema: [
            { AttributeName: partitionKey, KeyType: 'HASH' },
            { AttributeName: sortKey, KeyType: 'RANGE' }
        ],
        AttributeDefinitions: [
            { AttributeName: partitionKey, AttributeType: schema[partitionKey] },
            { AttributeName: sortKey, AttributeType: schema[sortKey] }
        ],
        BillingMode: 'PAY_PER_REQUEST',
        GlobalSecondaryIndexes: []
            };
            

    // Ensure that GlobalSecondaryIndexes is not empty before sending the command
    if (params.GlobalSecondaryIndexes.length === 0) {
        delete params.GlobalSecondaryIndexes;
    }

    try {
        await dynamoDB.send(new CreateTableCommand(params));
        console.log(`Table ${tableName} creation initiated`);
    } catch (error) {
        if (error.name === 'ResourceInUseException') {
            console.log(`Table ${tableName} already exists`);
        } else {
            throw error;
        }
    }
};
 
const waitForTable = async (tableName) => {
    try {
        await waitForTableExists(
            { client: dynamoDB, maxWaitTime: 60, minDelay: 5 },
            { TableName: tableName }
        );
        console.log(`Table ${tableName} is now active`);
    } catch (error) {
        console.error(`Error waiting for table ${tableName} to become active:`, error);
        throw error;
    }
};
 
const checkTableExists = async (tableName) => {
    try {
        await dynamoDB.send(new DescribeTableCommand({ TableName: tableName }));
        return true;
    } catch (error) {
        if (error.name === 'ResourceNotFoundException') {
            return false;
        }
        throw error;
    }
};
 
const ensureOrganizationsTableExists = async () => {
    const tableExists = await checkTableExists(tableName);
    if (!tableExists) {
        await createTable(tableName, 'PK', 'SK');
        await waitForTable(tableName);
    }
};
 
const createstudent = async (orgId, HostelName, studentData) => {
    const orgInitials = HostelName.toLowerCase().substring(0, 3);
    const combinedString = `${HostelName}-${studentData.firstName}`;
    const studentId = generateHash(combinedString);
    const student = {
        PK: `${orgInitials}#${orgId}`,
        SK: `${studentId}`,
        id: studentId,
        ...studentData,
        wardenId: studentData.wardenId || 'N/A',
        position: studentData.position || 'N/A',
    };
 
    await documentClient.send(new PutCommand({
        TableName: `${orgInitials}_${orgId}_students`,
        Item: student,
    }));
 
    console.log(`student created successfully with ID: ${studentId}`);
    return student;
};
 
const registerAdmin = async (adminName, password, parkingName, locationName) => {
    console.log("registerAdmin", adminName, password, parkingName, locationName);
    await ensureOrganizationsTableExists();

    const adminId = generateHash(parkingName);
    console.log("adminId", adminId);
    const hashedPassword = await bcrypt.hash(password, 10);
    const orgInitials = parkingName.toLowerCase().substring(0, 3);

    const adminData = {
        PK: `${orgInitials}#${adminId}`,
        SK: `METADATA#${adminId}`,
        id: adminId,
        adminName: adminName,
        password: hashedPassword,
        parkingName,
    };

    const existingAdmin = await documentClient.send(new GetCommand({
        TableName: tableName,
        Key: {
            PK: `${orgInitials}#${adminId}`,
            SK: `METADATA#${adminId}`,
        },
    }));

    if (existingAdmin.Item) {
        throw new Error('Admin already exists');
    }

    await documentClient.send(new PutCommand({
        TableName: tableName,
        Item: adminData,
    }));

    const tables = ['mobileDevices'];
    for (const table of tables) {
        await createTable(`${orgInitials}_${adminId}_${table}`, 'PK', 'SK');
        await waitForTable(`${orgInitials}_${adminId}_${table}`);
    }

    return { adminData };
};

const updateItemData = async (tableName, pk, sk, updateData) => {
    const updateExpressions = [];
    const expressionAttributeNames = {};
    const expressionAttributeValues = {};

    for (const [key, value] of Object.entries(updateData)) {
        updateExpressions.push(`#${key} = :${key}`);
        expressionAttributeNames[`#${key}`] = key;
        expressionAttributeValues[`:${key}`] = value;
    }

    const updateExpression = `SET ${updateExpressions.join(', ')}`;

    const params = {
        TableName: tableName,
        Key: {
            PK: pk,
            SK: sk
        },
        UpdateExpression: updateExpression,
        ExpressionAttributeNames: expressionAttributeNames,
        ExpressionAttributeValues: expressionAttributeValues,
        ReturnValues: 'UPDATED_NEW'
    };

    try {
        await documentClient.send(new UpdateCommand(params));
        console.log(`Item updated successfully in table ${tableName}`);
    } catch (error) {
        console.error(`Error updating item in table ${tableName}:`, error);
        throw error;
    }
};
 
const saveDataOnDynamo = async (tableName, pk, sk, data) => {
    const item = {
      PK: pk,
      SK: sk,
      ...data,
    };
 
    try {
        await documentClient.send(new PutCommand({
            TableName: tableName,
            Item: item,
        }));
        console.log(`Data saved successfully in table ${tableName}`);
        return item;
    } catch (error) {
        console.error(`Error saving data to table ${tableName}:`, error);
        throw error;
    }
};

const getstudentLeaveRecords = async (tableName, pk, empId) => {
    const params = {
        TableName: tableName,
        KeyConditionExpression: 'PK = :pk and begins_with(SK, :empId)',
        ExpressionAttributeValues: {
            ':pk': pk,
            ':empId': empId,
        },
    };

    try {
        const data = await documentClient.send(new QueryCommand(params));
        return data.Items;
    } catch (error) {
        console.error('Error fetching data from DynamoDB:', error);
        throw new Error('Error fetching data from DynamoDB');
    }
};
 
 
const getTableData = async (tableName) => {
    try {
        const data = await dynamoDB.send(new ScanCommand({ TableName: tableName }));
        return data.Items;
    } catch (error) {
        console.error(`Error retrieving data from table ${tableName}:`, error);
        throw error;
    }
};
 
const getItemData = async (tableName, pk, sk) => {
    try {
        const result = await documentClient.send(new GetCommand({
            TableName: tableName,
            Key: {
                PK: pk,
                SK: sk,
            },
        }));
        return result.Item;
    } catch (error) {
        console.error(`Error retrieving item from table ${tableName}:`, error);
        throw error;
    }
};


const queryTable = async (tableName, indexName, attributeName, attributeValue) => {
    console.log('tableName', tableName);
    console.log('indexName', indexName);
    console.log('attributeName', attributeName);
    console.log('attributeValue', attributeValue);
    const params = {
        TableName: tableName,
        IndexName: indexName, // Dynamically specify the index name
        KeyConditionExpression: '#attr = :value',
        ExpressionAttributeNames: {
            '#attr': attributeName,
        },
        ExpressionAttributeValues: {
            ':value': attributeValue,
        },
    };
  
    try {
        const result = await documentClient.send(new QueryCommand(params));
        return result.Items;
    } catch (error) {
        console.error(`Error querying table ${tableName}:`, error);
        throw error;
    }
  };

// function to create attendance record for the particular student for the current date.
const createstudentAttendance = async (HostelName,empId,date,attendanceData) => {
  const orgInitials = HostelName.toLowerCase().substring(0, 3);
  const orgHash = generateHash(HostelName);
  const combinedString = `${empId}-${date}`;
  const attendanceId = generateHash(combinedString);

  const attendance = {
    PK: `${orgInitials}#${orgHash}`, // Organization-based partition key
    SK: `${attendanceId}`, // student-based sort key with date
    empId,
    Date: date,
    ...attendanceData,
  };
    // console.log("orgName: ", HostelName);
    const tableName = `${orgInitials}_${orgHash}_attendance`; // Table specific to org attendance
    // console.log("tableName: ",tableName);

  await documentClient.send(
    new PutCommand({
      TableName: tableName,
      Item: attendance,
    })
  );

  console.log(
    `Attendance recorded successfully for student: ${empId} on ${date}`
  );
  return attendance;
};

// Fetch existing attendance data
const getstudentAttendance = async (HostelName, empId, date) => {
  const orgInitials = HostelName.toLowerCase().substring(0, 3);
  const orgHash = generateHash(HostelName);
  const combinedString = `${empId}-${date}`;
  const attendanceId = generateHash(combinedString);

  const tableName = `${orgInitials}_${orgHash}_attendance`;

  const params = {
    TableName: tableName,
    Key: {
      PK: `${orgInitials}#${orgHash}`,
      SK: `${attendanceId}`
    }
  };

  try {
      const result = await documentClient.send(new GetCommand(params));
      
    return result.Item;
  } catch (error) {
    console.error('Error fetching student attendance:', error);
    throw new Error('Error fetching student attendance');
  }
};

// Update attendance data
// const updatestudentAttendance = async (HostelName, empId, date, updateData) => {
//   const orgInitials = HostelName.toLowerCase().substring(0, 3);
//   const orgHash = generateHash(HostelName);
//   const combinedString = `${empId}-${date}`;
//   const attendanceId = generateHash(combinedString);

//   const tableName = `${orgInitials}_${orgHash}_attendance`;

//   const params = {
//     TableName: tableName,
//     Key: {
//       PK: `${orgInitials}#${orgHash}`,
//       SK: `${attendanceId}`
//     },
//     UpdateExpression: 'SET #status = :status, #logoutTime = :logoutTime, #totalMins = :totalMins',
//     ExpressionAttributeNames: {
//       '#status': 'status',
//       '#logoutTime': 'logoutTime',
//       '#totalMins': 'totalMins'
//     },
//     ExpressionAttributeValues: {
//       ':status': updateData.status,
//       ':logoutTime': updateData.logoutTime,
//       ':totalMins': updateData.totalMins
//     }
//   };

//   try {
//     await documentClient.send(new UpdateCommand(params));
//   } catch (error) {
//     console.error('Error updating student attendance:', error);
//     throw new Error('Error updating student attendance');
//   }
// };

const updateLeaveAttendance = async (HostelName, empId, date, leaveData) => {
    const orgInitials = HostelName.toLowerCase().substring(0, 3);
    const orgHash = generateHash(HostelName);
    const combinedString = `${empId}-${date}`;
    const attendanceId = generateHash(combinedString);

    const tableName = `${orgInitials}_${orgHash}_attendance`;
    console.log('data in update student', { HostelName, tableName, attendanceId });

    // Check if attendance exists
  let attendance = await getstudentAttendance(HostelName, empId, date);
  if (!attendance) {
    console.log('creating student attendance');
      await createstudentAttendance(HostelName, empId, date, leaveData);
  }
    // Build the update expression dynamically based on which shift data is being updated
    let updateExpression = "SET";
    let expressionAttributeNames = {};
    let expressionAttributeValues = {};

    if (leaveData.s1Status !== undefined) {
        updateExpression += " #s1Status = :s1Status,";
        expressionAttributeNames["#s1Status"] = "s1Status";
        expressionAttributeValues[":s1Status"] = leaveData.s1Status;
    }

    if (leaveData.s2Status !== undefined) {
        updateExpression += " #s2Status = :s2Status,";
        expressionAttributeNames["#s2Status"] = "s2Status";
        expressionAttributeValues[":s2Status"] = leaveData.s2Status;
    }

    if (leaveData.status) {
        updateExpression += " #status = :status,";
        expressionAttributeNames["#status"] = "status";
        expressionAttributeValues[":status"] = leaveData.status;
    }

    // Remove the trailing comma from the update expression
    updateExpression = updateExpression.slice(0, -1);

    const params = {
        TableName: tableName,
        Key: {
            PK: `${orgInitials}#${orgHash}`,
            SK: `${attendanceId}`,
        },
        UpdateExpression: updateExpression,
        ExpressionAttributeNames: expressionAttributeNames,
        ExpressionAttributeValues: expressionAttributeValues,
    };

    try {
        await documentClient.send(new UpdateCommand(params));
        console.log('student attendance updated successfully');
    } catch (error) {
        console.error("Error updating student attendance:", error);
        throw new Error("Error updating student attendance");
    }
};

// function to update the attendance attribute values.
const updatestudentAttendance = async (HostelName,empId,date,updateData) => {

  const orgInitials = HostelName.toLowerCase().substring(0, 3);
  const orgHash = generateHash(HostelName);
  const combinedString = `${empId}-${date}`;
  const attendanceId = generateHash(combinedString);

  const tableName = `${orgInitials}_${orgHash}_attendance`;
  console.log('data in update student', {HostelName,tableName,attendanceId});
  // Build the update expression dynamically based on which shift data is being updated
  let updateExpression = "SET";
  let expressionAttributeNames = {};
  let expressionAttributeValues = {};

  if (updateData.s1LoginTime) {
    updateExpression += " #s1LoginTime = :s1LoginTime,";
    expressionAttributeNames["#s1LoginTime"] = "s1LoginTime";
    expressionAttributeValues[":s1LoginTime"] = updateData.s1LoginTime;
  }

  if (updateData.s1LogoutTime) {
    updateExpression += " #s1LogoutTime = :s1LogoutTime,";
    expressionAttributeNames["#s1LogoutTime"] = "s1LogoutTime";
    expressionAttributeValues[":s1LogoutTime"] = updateData.s1LogoutTime;
  }

  if (updateData.s1Status) {
    updateExpression += " #s1Status = :s1Status,";
    expressionAttributeNames["#s1Status"] = "s1Status";
    expressionAttributeValues[":s1Status"] = updateData.s1Status;
  }

  if (updateData.status) {
    updateExpression += " #status = :status,";
    expressionAttributeNames["#status"] = "status";
    expressionAttributeValues[":status"] = updateData.status;
    }
    
  if (updateData.s1Time) {
    updateExpression += " #s1Time = :s1Time,";
    expressionAttributeNames["#s1Time"] = "s1Time";
    expressionAttributeValues[":s1Time"] = updateData.s1Time;
  }

  if (updateData.s2LoginTime) {
    updateExpression += " #s2LoginTime = :s2LoginTime,";
    expressionAttributeNames["#s2LoginTime"] = "s2LoginTime";
    expressionAttributeValues[":s2LoginTime"] = updateData.s2LoginTime;
  }

  if (updateData.s2LogoutTime) {
    updateExpression += " #s2LogoutTime = :s2LogoutTime,";
    expressionAttributeNames["#s2LogoutTime"] = "s2LogoutTime";
    expressionAttributeValues[":s2LogoutTime"] = updateData.s2LogoutTime;
  }

  if (updateData.s2Status) {
    updateExpression += " #s2Status = :s2Status,";
    expressionAttributeNames["#s2Status"] = "s2Status";
    expressionAttributeValues[":s2Status"] = updateData.s2Status;
  }

  if (updateData.s2Time) {
    updateExpression += " #s2Time = :s2Time,";
    expressionAttributeNames["#s2Time"] = "s2Time";
    expressionAttributeValues[":s2Time"] = updateData.s2Time;
  }

  if (updateData.totalTime) {
    updateExpression += " #totalTime = :totalTime,";
    expressionAttributeNames["#totalTime"] = "totalTime";
    expressionAttributeValues[":totalTime"] = updateData.totalTime;
  }

  // Remove the trailing comma from the update expression
  updateExpression = updateExpression.slice(0, -1);

  const params = {
    TableName: tableName,
    Key: {
      PK: `${orgInitials}#${orgHash}`,
      SK: `${attendanceId}`,
    },
    UpdateExpression: updateExpression,
    ExpressionAttributeNames: expressionAttributeNames,
    ExpressionAttributeValues: expressionAttributeValues,
  };

  try {
    await documentClient.send(new UpdateCommand(params));
  } catch (error) {
    console.error("Error updating student attendance:", error);
    throw new Error("Error updating student attendance");
  }
};


const deletestudentData = async (data) => {
    try{
        const organization = data.organization;
        const studentId = data.studentId;
        const hashOrg = generateHash(organization);
        const combineString = `${organization}-${studentId}`;
        const orgIntials = organization.substring(0,3);
        const pk1 = `${orgIntials}#${hashOrg}`;
        const sk1 = generateHash(combineString);
        const tables = ['students', 'studentData', 'attendance', 'leaveData'];

        for (const table of tables) {
            const tableName = `${orgIntials}_${hashOrg}_${table}`;
            let defaultSk = sk1;

            //use studentId for sk if table is leaveData table
            if(table === 'leaveData'){
                defaultSk = studentId;
            }
            try{
            await documentClient.send(new DeleteCommand({
                TableName: tableName,
                Key: {
                    PK: pk1,
                    SK: defaultSk,
                },
            }));
            console.log(`student data deleted successfully from table ${tableName}`);
        }catch(error){
          if (error.name === 'ResourceNotFoundException') {
            console.log(`Table ${tableName} does not exist, skipping...`);
        } else if (error.name === 'ConditionalCheckFailedException') {
            console.log(`student data not found in table ${tableName}, skipping...`);
        } else {
            console.error(`Error deleting student data from table ${tableName}:`, error);
            throw error; // Rethrow the error if it's not a known issue
        }
    }
  }
}
catch(error){

    console.log("error in deleting student data: ",error);
}
}

// Function to dynamically update student records
const updatestudentRecords = async (tableName, pk, sk, updateData) => {
  const updateExpressions = [];
  const removeExpressions = [];
  const expressionAttributeNames = {};
  const expressionAttributeValues = {};

  for (const [key, value] of Object.entries(updateData)) {
      if (value !== undefined) { // Ensure no undefined values are included
          if (value === null) {
              removeExpressions.push(`#${key}`);
              expressionAttributeNames[`#${key}`] = key;
          } else {
              updateExpressions.push(`#${key} = :${key}`);
              expressionAttributeNames[`#${key}`] = key;
              expressionAttributeValues[`:${key}`] = value;
          }
      }
  }

  const updateExpression = updateExpressions.length > 0 ? `SET ${updateExpressions.join(', ')}` : '';
  const removeExpression = removeExpressions.length > 0 ? `REMOVE ${removeExpressions.join(', ')}` : '';
  const combinedExpression = [updateExpression, removeExpression].filter(Boolean).join(' ');

  const params = {
      TableName: tableName,
      Key: {
          PK: pk,
          SK: sk
      },
      UpdateExpression: combinedExpression,
      ExpressionAttributeNames: expressionAttributeNames,
      ReturnValues: 'UPDATED_NEW'
  };

  if (Object.keys(expressionAttributeValues).length > 0) {
      params.ExpressionAttributeValues = expressionAttributeValues;
  }

  try {
      await documentClient.send(new UpdateCommand(params));
      console.log(`student record updated successfully in table ${tableName}`);
  } catch (error) {
      console.error(`Error updating student record in table ${tableName}:`, error);
      throw error;
  }
};


module.exports = {
  createTable,
  waitForTable,
  checkTableExists,
  registerAdmin,
  getTableData,
  getItemData,
  saveDataOnDynamo,
deletestudentData,
  createstudentAttendance,
  getstudentAttendance,
  updatestudentAttendance,
  updatestudentRecords,
  updateLeaveAttendance,
  queryTable,
  getstudentLeaveRecords,
  updateItemData
};