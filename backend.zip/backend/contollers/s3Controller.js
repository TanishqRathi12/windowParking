const { s3, PutObjectCommand, ListObjectsV2Command } = require('../awsClients/s3Client');
const { AWS_BUCKET_NAME } = require('../env.js');

// Function t   o create a folder in S3
const createFolder = async (folderName) => {
    const params = {
        Bucket: AWS_BUCKET_NAME,
        Key: `${folderName}/`,  // S3 treats keys ending with '/' as folders
    };

    try {
        await s3.send(new PutObjectCommand(params));
        console.log(`Folder ${folderName} created in bucket ${AWS_BUCKET_NAME}`);
    } catch (err) {
        console.error("Error creating folder", err);
    }
}

// Function to upload a file to S3
const uploadFile = async (folderName, fileName, fileContent) => {
    const params = {
        Bucket: AWS_BUCKET_NAME,
        Key: `${folderName}/${fileName}`,
        Body: fileContent
    };

    try {
        await s3.send(new PutObjectCommand(params));
        console.log(`File ${fileName} uploaded to folder ${folderName}`);
    } catch (err) {
        console.error("Error uploading file", err);
    }
}

// Function to list files in a folder in S3
const listFiles = async (folderName) => {
    const params = {
        Bucket: AWS_BUCKET_NAME,
        Prefix: `${folderName}/`
    };

    try {
        const data = await s3.send(new ListObjectsV2Command(params));
        return data.Contents.map(item => item.Key);
    } catch (err) {
        console.error("Error listing files", err);
    }
}

const getFiles = async (folderName) => {
    try {
        const fileKeys = await listFiles(folderName);
        return fileKeys;
    } catch (err) {
        console.error("Error getting files", err);
    }
}

module.exports = {
    createFolder,
    uploadFile,
    listFiles,
    getFiles
};